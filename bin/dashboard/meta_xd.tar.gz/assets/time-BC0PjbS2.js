import{Y as a,b6 as m}from"./index-DdEpW1wR.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
