import{Y as a,b6 as m}from"./index-CtVw7BLk.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
