import{W as a,b4 as m}from"./index-BfxF6Zjo.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
