import{a6 as a,b6 as m}from"./index-BewbZUDr.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
