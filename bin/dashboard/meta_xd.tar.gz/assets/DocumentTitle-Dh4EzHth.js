import{f as t,bD as r}from"./index-BPVK8l7-.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
