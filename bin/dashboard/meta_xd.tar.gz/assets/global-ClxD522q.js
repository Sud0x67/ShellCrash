import{a5 as a,a_ as m}from"./index-D_FQwHPh.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
